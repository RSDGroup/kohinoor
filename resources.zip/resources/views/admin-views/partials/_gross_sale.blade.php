<h6>{{\App\CentralLogics\Helpers::format_currency(array_sum($data['total_sell']))}}</h6>
<span>{{ translate('messages.Gross Sale') }}</span>